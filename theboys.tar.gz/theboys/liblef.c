#include <stdlib.h>
#include <string.h>

#include "liblef.h"

/*
 * Cria uma LEF vazia
 */
lef_t *cria_lef()
{
    lef_t *pont;

    if (!(pont = malloc(sizeof(lef_t))))
        return NULL;
    pont->Primeiro = NULL;

    return pont;
}

/*
 * Destroi a LEF e retorna NULL.
 */
lef_t *destroi_lef(lef_t *l)
{
    nodo_lef_t *aux;
    while (l->Primeiro != NULL)
    {
        aux = l->Primeiro;
        l->Primeiro = l->Primeiro->prox;
        free(aux->evento);
        free(aux);
    }
    free(l);
    return NULL;
}

/*
 * Adiciona um evento na primeira posicao da LEF. Uma nova copia
 * da estrutura evento sera feita.
 * Retorna 1 em caso de sucesso, 0 caso contrario.
 */
int adiciona_inicio_lef(lef_t *l, evento_t *evento)
{
    nodo_lef_t *novo;
    evento_t *event;

    if (!(novo = malloc(sizeof(nodo_lef_t))))
        return 0;

    if (!(event = malloc(sizeof(evento_t))))
        return 0;

    novo->prox = l->Primeiro;
    l->Primeiro = novo;

    novo->evento = event;
    memcpy(novo->evento, evento, sizeof(evento_t));

    return 1;
}

/*
 * Retorna um ponteiro para o nodo ao qual deve ter um proximo com o tempo 'temp'.
 */
nodo_lef_t *pont_add(lef_t *l, int temp)
{
    nodo_lef_t *ant;
    ant = l->Primeiro;

    while ((ant->prox != NULL) && (ant->prox->evento->tempo < temp))
        ant = ant->prox;

    return ant;
}

/*
 * Adiciona um evento de acordo com o valor evento->tempo na LEF.
 * Uma nova copia da estrutura evento sera feita
 * Retorna 1 em caso de sucesso, 0 caso contrario.
 */
int adiciona_ordem_lef(lef_t *l, evento_t *evento)
{
    nodo_lef_t *novo, *pont;
    evento_t *event;

    if (!(novo = malloc(sizeof(nodo_lef_t))))
        return 0;

    if (!(event = malloc(sizeof(evento_t))))
        return 0;

    if ((l->Primeiro == NULL) || (evento->tempo < l->Primeiro->evento->tempo))
    {
        novo->prox = l->Primeiro;
        l->Primeiro = novo;
    }
    else
    {

        pont = pont_add(l, evento->tempo);
        novo->prox = pont->prox;
        pont->prox = novo;
    }

    novo->evento = event;
    memcpy(novo->evento, evento, sizeof(evento_t));

    return 1;
}

/*
 * Retorna e retira o primeiro evento da LEF.
 * A responsabilidade por desalocar
 * a memoria associada eh de quem chama essa funcao.
 */
evento_t *obtem_primeiro_lef(lef_t *l)
{
    nodo_lef_t *guarda;
    evento_t *event;

    if (l->Primeiro == NULL)
        return NULL;

    guarda = l->Primeiro;
    l->Primeiro = l->Primeiro->prox;

    event = guarda->evento;
    free(guarda);

    return event;
}
